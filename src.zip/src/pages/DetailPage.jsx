import React from "react";

const DetailPage = () => {
  return (
    <div>
      <h2>Detail Page</h2>
    </div>
  );
};

export default DetailPage;
