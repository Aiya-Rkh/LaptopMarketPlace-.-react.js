import MyRoutes from "./MyRoutes";

function App() {
  return <MyRoutes />;
}

export default App;
