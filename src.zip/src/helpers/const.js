export const API = "http://localhost:8000/products";
